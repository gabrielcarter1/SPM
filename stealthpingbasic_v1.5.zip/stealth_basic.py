# StealthPing Basic Core Script
print('Running StealthPing Basic...')
