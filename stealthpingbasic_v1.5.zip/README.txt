README for StealthPingBasic v1.5
Usage instructions go here.
