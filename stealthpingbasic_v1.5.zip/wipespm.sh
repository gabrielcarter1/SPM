# Wipe Script
#!/data/data/com.termux/files/usr/bin/bash
echo 'Wiping contacts and configs...'
