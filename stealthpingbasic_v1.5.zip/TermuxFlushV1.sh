# Termux Flush Script
#!/data/data/com.termux/files/usr/bin/bash
echo 'Flushing setup...'
