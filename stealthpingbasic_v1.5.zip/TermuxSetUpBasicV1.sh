# Termux Setup Script
#!/data/data/com.termux/files/usr/bin/bash
echo 'Setting up...'
